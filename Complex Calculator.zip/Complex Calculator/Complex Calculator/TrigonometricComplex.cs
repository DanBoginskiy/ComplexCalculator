﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Complex_Calculator
{
    public class TrigonometricComplex
    {
        public double Phi { get; private set; }
        public double R { get; private set; }

        private double real;
        private double imaginary;

        public TrigonometricComplex(double phi, double r)
        {
            this.Phi = phi;
            this.R = r;
        }

        public void ToAlgForm()
        {
            this.real = R * Math.Cos(Phi);
            this.imaginary = R * Math.Sin(Phi);
        }

        public static TrigonometricComplex operator +(TrigonometricComplex c1, TrigonometricComplex c2)
        {
            c1.ToAlgForm();
            c2.ToAlgForm();
            double realPart = c1.real + c2.real;
            double imaginaryPart = c1.imaginary + c2.imaginary;
            double r = Math.Sqrt(realPart * realPart + imaginaryPart * imaginaryPart);
            double phi = Math.Atan2(imaginaryPart, realPart);
            return new TrigonometricComplex(phi, r);
        }

        public static TrigonometricComplex operator -(TrigonometricComplex c1, TrigonometricComplex c2)
        {
            c1.ToAlgForm();
            c2.ToAlgForm();
            double realPart = c1.real - c2.real;
            double imaginaryPart = c1.imaginary - c2.imaginary;
            double r = Math.Sqrt(realPart * realPart + imaginaryPart * imaginaryPart);
            double phi = Math.Atan2(imaginaryPart, realPart);
            return new TrigonometricComplex(phi, r);
        }

        public static TrigonometricComplex operator *(TrigonometricComplex c1, TrigonometricComplex c2)
        {
            double newR = c1.R * c2.R;
            double newPhi = c1.Phi + c2.Phi;
            return new TrigonometricComplex(newPhi, newR);
        }
        public static TrigonometricComplex operator /(TrigonometricComplex c1, TrigonometricComplex c2)
        {
            if (c2.R == 0)
                throw new DivideByZeroException("Ділення на нуль (нульовий знаменник).");
            double newR = c1.R / c2.R;
            double newPhi = c1.Phi - c2.Phi;
            return new TrigonometricComplex(newPhi, newR);
        }

        public TrigonometricComplex Power(int n)
        {
            double newR = Math.Pow(this.R, n);
            double newPhi = this.Phi * n;
            return new TrigonometricComplex(newPhi, newR);
        }

        public TrigonometricComplex Root(int n)
        {
            if (n <= 0)
                throw new ArgumentException("Корінь повинен бути додатним цілим числом.");
            double newR = Math.Pow(this.R, 1.0 / n);
            double newPhi = this.Phi / n;
            return new TrigonometricComplex(newPhi, newR);
        }

        public AlgebraicComplex Toalg()
        {
            double a = R * Math.Cos(Phi);
            double b = R * Math.Sin(Phi);
            return new AlgebraicComplex(a, b);
        }

        public override string ToString()
        {
            return $"{R:F2} (cos({Phi:F2}) + i sin({Phi:F2}))";
        }
    }
}

