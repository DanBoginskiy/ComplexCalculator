﻿namespace Complex_Calculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            label1 = new Label();
            label2 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label3 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            radioButton3 = new RadioButton();
            radioButton4 = new RadioButton();
            radioButton5 = new RadioButton();
            radioButton6 = new RadioButton();
            radioButton7 = new RadioButton();
            radioButton8 = new RadioButton();
            radioButton9 = new RadioButton();
            radioButton10 = new RadioButton();
            radioButton11 = new RadioButton();
            label4 = new Label();
            textBox3 = new TextBox();
            radioButton12 = new RadioButton();
            radioButton13 = new RadioButton();
            radioButton14 = new RadioButton();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            label5 = new Label();
            label6 = new Label();
            SuspendLayout();
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(12, 12);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(168, 24);
            radioButton1.TabIndex = 0;
            radioButton1.TabStop = true;
            radioButton1.Text = "Алгебраїчна форма";
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.CheckedChanged += Alg;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(12, 42);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(208, 24);
            radioButton2.TabIndex = 1;
            radioButton2.TabStop = true;
            radioButton2.Text = "Тригонометрична форма";
            radioButton2.UseVisualStyleBackColor = true;
            radioButton2.CheckedChanged += Trig;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 78);
            label1.Name = "label1";
            label1.Size = new Size(50, 20);
            label1.TabIndex = 2;
            label1.Text = "label1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 109);
            label2.Name = "label2";
            label2.Size = new Size(50, 20);
            label2.TabIndex = 3;
            label2.Text = "label2";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(68, 71);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(35, 27);
            textBox1.TabIndex = 4;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(68, 104);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(35, 27);
            textBox2.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 145);
            label3.Name = "label3";
            label3.Size = new Size(76, 20);
            label3.TabIndex = 6;
            label3.Text = "Відповідь";
            // 
            // button1
            // 
            button1.Location = new Point(12, 180);
            button1.Name = "button1";
            button1.Size = new Size(28, 29);
            button1.TabIndex = 7;
            button1.Text = "1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += NumberButton_Click;
            // 
            // button2
            // 
            button2.Location = new Point(46, 180);
            button2.Name = "button2";
            button2.Size = new Size(28, 29);
            button2.TabIndex = 8;
            button2.Text = "2";
            button2.UseVisualStyleBackColor = true;
            button2.Click += NumberButton_Click;
            // 
            // button3
            // 
            button3.Location = new Point(80, 180);
            button3.Name = "button3";
            button3.Size = new Size(28, 29);
            button3.TabIndex = 9;
            button3.Text = "3";
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Location = new Point(80, 215);
            button4.Name = "button4";
            button4.Size = new Size(28, 29);
            button4.TabIndex = 12;
            button4.Text = "6";
            button4.UseVisualStyleBackColor = true;
            button4.Click += NumberButton_Click;
            // 
            // button5
            // 
            button5.Location = new Point(46, 215);
            button5.Name = "button5";
            button5.Size = new Size(28, 29);
            button5.TabIndex = 11;
            button5.Text = "5";
            button5.UseVisualStyleBackColor = true;
            button5.Click += NumberButton_Click;
            // 
            // button6
            // 
            button6.Location = new Point(12, 215);
            button6.Name = "button6";
            button6.Size = new Size(28, 29);
            button6.TabIndex = 10;
            button6.Text = "4";
            button6.UseVisualStyleBackColor = true;
            button6.Click += NumberButton_Click;
            // 
            // button7
            // 
            button7.Location = new Point(80, 250);
            button7.Name = "button7";
            button7.Size = new Size(28, 29);
            button7.TabIndex = 15;
            button7.Text = "9";
            button7.UseVisualStyleBackColor = true;
            button7.Click += NumberButton_Click;
            // 
            // button8
            // 
            button8.Location = new Point(46, 250);
            button8.Name = "button8";
            button8.Size = new Size(28, 29);
            button8.TabIndex = 14;
            button8.Text = "8";
            button8.UseVisualStyleBackColor = true;
            button8.Click += NumberButton_Click;
            // 
            // button9
            // 
            button9.Location = new Point(12, 250);
            button9.Name = "button9";
            button9.Size = new Size(28, 29);
            button9.TabIndex = 13;
            button9.Text = "7";
            button9.UseVisualStyleBackColor = true;
            button9.Click += NumberButton_Click;
            // 
            // button10
            // 
            button10.BackColor = Color.IndianRed;
            button10.Location = new Point(114, 180);
            button10.Name = "button10";
            button10.Size = new Size(28, 29);
            button10.TabIndex = 18;
            button10.Text = "C";
            button10.UseVisualStyleBackColor = false;
            button10.Click += Clear_Click;
            // 
            // button11
            // 
            button11.Location = new Point(46, 285);
            button11.Name = "button11";
            button11.Size = new Size(28, 29);
            button11.TabIndex = 17;
            button11.Text = "0";
            button11.UseVisualStyleBackColor = true;
            button11.Click += NumberButton_Click;
            // 
            // button12
            // 
            button12.Location = new Point(12, 285);
            button12.Name = "button12";
            button12.Size = new Size(28, 29);
            button12.TabIndex = 16;
            button12.Text = ".";
            button12.UseVisualStyleBackColor = true;
            button12.Click += NumberButton_Click;
            // 
            // button13
            // 
            button13.Location = new Point(114, 215);
            button13.Name = "button13";
            button13.Size = new Size(28, 29);
            button13.TabIndex = 19;
            button13.Text = "=";
            button13.UseVisualStyleBackColor = true;
            button13.Click += Eq_Click;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Location = new Point(168, 185);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(40, 24);
            radioButton3.TabIndex = 20;
            radioButton3.TabStop = true;
            radioButton3.Text = "+";
            radioButton3.UseVisualStyleBackColor = true;
            radioButton3.CheckedChanged += OperationalButton;
            // 
            // radioButton4
            // 
            radioButton4.AutoSize = true;
            radioButton4.Location = new Point(168, 215);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(36, 24);
            radioButton4.TabIndex = 21;
            radioButton4.TabStop = true;
            radioButton4.Text = "-";
            radioButton4.UseVisualStyleBackColor = true;
            radioButton4.CheckedChanged += OperationalButton;
            // 
            // radioButton5
            // 
            radioButton5.AutoSize = true;
            radioButton5.Location = new Point(168, 245);
            radioButton5.Name = "radioButton5";
            radioButton5.Size = new Size(36, 24);
            radioButton5.TabIndex = 22;
            radioButton5.TabStop = true;
            radioButton5.Text = "*";
            radioButton5.UseVisualStyleBackColor = true;
            radioButton5.CheckedChanged += OperationalButton;
            // 
            // radioButton6
            // 
            radioButton6.AutoSize = true;
            radioButton6.Location = new Point(168, 275);
            radioButton6.Name = "radioButton6";
            radioButton6.Size = new Size(36, 24);
            radioButton6.TabIndex = 23;
            radioButton6.TabStop = true;
            radioButton6.Text = "/";
            radioButton6.UseVisualStyleBackColor = true;
            radioButton6.CheckedChanged += OperationalButton;
            // 
            // radioButton7
            // 
            radioButton7.AutoSize = true;
            radioButton7.Location = new Point(214, 185);
            radioButton7.Name = "radioButton7";
            radioButton7.Size = new Size(40, 24);
            radioButton7.TabIndex = 24;
            radioButton7.TabStop = true;
            radioButton7.Text = "^";
            radioButton7.UseVisualStyleBackColor = true;
            radioButton7.CheckedChanged += POW_CheckedChanged;
            // 
            // radioButton8
            // 
            radioButton8.AutoSize = true;
            radioButton8.Location = new Point(210, 215);
            radioButton8.Name = "radioButton8";
            radioButton8.Size = new Size(55, 24);
            radioButton8.TabIndex = 25;
            radioButton8.TabStop = true;
            radioButton8.Text = "sqrt";
            radioButton8.UseVisualStyleBackColor = true;
            radioButton8.CheckedChanged += SQRT_CheckedChanged;
            // 
            // radioButton9
            // 
            radioButton9.AutoSize = true;
            radioButton9.Location = new Point(114, 72);
            radioButton9.Name = "radioButton9";
            radioButton9.Size = new Size(17, 16);
            radioButton9.TabIndex = 26;
            radioButton9.TabStop = true;
            radioButton9.UseVisualStyleBackColor = true;
            radioButton9.CheckedChanged += Field1_CheckedChanged;
            // 
            // radioButton10
            // 
            radioButton10.AutoSize = true;
            radioButton10.Location = new Point(114, 107);
            radioButton10.Name = "radioButton10";
            radioButton10.Size = new Size(17, 16);
            radioButton10.TabIndex = 27;
            radioButton10.TabStop = true;
            radioButton10.UseVisualStyleBackColor = true;
            radioButton10.CheckedChanged += Field2_CheckedChanged;
            // 
            // radioButton11
            // 
            radioButton11.AutoSize = true;
            radioButton11.Location = new Point(210, 245);
            radioButton11.Name = "radioButton11";
            radioButton11.Size = new Size(102, 24);
            radioButton11.TabIndex = 28;
            radioButton11.TabStop = true;
            radioButton11.Text = "перевести";
            radioButton11.UseVisualStyleBackColor = true;
            radioButton11.CheckedChanged += Alter_CheckedChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(212, 280);
            label4.Name = "label4";
            label4.Size = new Size(20, 20);
            label4.TabIndex = 29;
            label4.Text = "n:";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(238, 275);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(46, 27);
            textBox3.TabIndex = 30;
            // 
            // radioButton12
            // 
            radioButton12.AutoSize = true;
            radioButton12.Location = new Point(290, 282);
            radioButton12.Name = "radioButton12";
            radioButton12.Size = new Size(17, 16);
            radioButton12.TabIndex = 31;
            radioButton12.TabStop = true;
            radioButton12.UseVisualStyleBackColor = true;
            radioButton12.CheckedChanged += Field3_CheckedChanged;
            // 
            // radioButton13
            // 
            radioButton13.AutoSize = true;
            radioButton13.Location = new Point(256, 107);
            radioButton13.Name = "radioButton13";
            radioButton13.Size = new Size(17, 16);
            radioButton13.TabIndex = 37;
            radioButton13.TabStop = true;
            radioButton13.UseVisualStyleBackColor = true;
            radioButton13.CheckedChanged += Field4_CheckedChanged;
            // 
            // radioButton14
            // 
            radioButton14.AutoSize = true;
            radioButton14.Location = new Point(256, 72);
            radioButton14.Name = "radioButton14";
            radioButton14.Size = new Size(17, 16);
            radioButton14.TabIndex = 36;
            radioButton14.TabStop = true;
            radioButton14.UseVisualStyleBackColor = true;
            radioButton14.CheckedChanged += Field5_CheckedChanged;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(210, 104);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(35, 27);
            textBox4.TabIndex = 35;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(210, 71);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(35, 27);
            textBox5.TabIndex = 34;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(154, 109);
            label5.Name = "label5";
            label5.Size = new Size(50, 20);
            label5.TabIndex = 33;
            label5.Text = "label5";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(154, 78);
            label6.Name = "label6";
            label6.Size = new Size(50, 20);
            label6.TabIndex = 32;
            label6.Text = "label6";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(349, 342);
            Controls.Add(radioButton13);
            Controls.Add(radioButton14);
            Controls.Add(textBox4);
            Controls.Add(textBox5);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(radioButton12);
            Controls.Add(textBox3);
            Controls.Add(label4);
            Controls.Add(radioButton11);
            Controls.Add(radioButton10);
            Controls.Add(radioButton9);
            Controls.Add(radioButton8);
            Controls.Add(radioButton7);
            Controls.Add(radioButton6);
            Controls.Add(radioButton5);
            Controls.Add(radioButton4);
            Controls.Add(radioButton3);
            Controls.Add(button13);
            Controls.Add(button10);
            Controls.Add(button11);
            Controls.Add(button12);
            Controls.Add(button7);
            Controls.Add(button8);
            Controls.Add(button9);
            Controls.Add(button4);
            Controls.Add(button5);
            Controls.Add(button6);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(radioButton2);
            Controls.Add(radioButton1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private Label label1;
        private Label label2;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label3;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private RadioButton radioButton3;
        private RadioButton radioButton4;
        private RadioButton radioButton5;
        private RadioButton radioButton6;
        private RadioButton radioButton7;
        private RadioButton radioButton8;
        private RadioButton radioButton9;
        private RadioButton radioButton10;
        private RadioButton radioButton11;
        private Label label4;
        private TextBox textBox3;
        private RadioButton radioButton12;
        private RadioButton radioButton13;
        private RadioButton radioButton14;
        private TextBox textBox4;
        private TextBox textBox5;
        private Label label5;
        private Label label6;
    }
}
