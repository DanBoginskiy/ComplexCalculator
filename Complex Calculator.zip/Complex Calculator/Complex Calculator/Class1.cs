﻿using System;

namespace ComplexCalculator
{
    // FIX: Клас, що реалізує комплексне число та його математичні операції
    public class ComplexNumber
    {
        public double Real { get; private set; }
        public double Imaginary { get; private set; }

        private double? _r = null;
        private double? _theta = null;
        public bool IsTrigFormComputed => _r.HasValue && _theta.HasValue;

        public ComplexNumber(double real, double imaginary)
        {
            this.Real = real;
            this.Imaginary = imaginary;
            _r = null;
            _theta = null;
        }

        // --- Внутрішня логіка форм ---
        private void ToTrigForm()
        {
            if (!_r.HasValue || !_theta.HasValue)
            {
                _r = Math.Sqrt(Real * Real + Imaginary * Imaginary);
                _theta = Math.Atan2(Imaginary, Real);
            }
        }

        public ComplexNumber ToPolar()
        {
            double r = Math.Sqrt(Real * Real + Imaginary * Imaginary);
            double theta = Math.Atan2(Imaginary, Real);

            // Створюємо новий об'єкт, що містить полярні значення як основні
            return new ComplexNumber(r, theta) { _r = r, _theta = theta };
        }

        public static ComplexNumber ToAlg(ComplexNumber polar)
        {
            if (!polar.IsTrigFormComputed)
            {
                // Для цілей калькулятора, ми просто обчислимо його, якщо форма не була встановлена
                polar.ToTrigForm();
            }

            double r = polar._r.Value;
            double theta = polar._theta.Value;

            double real = r * Math.Cos(theta);
            double imaginary = r * Math.Sin(theta);

            return new ComplexNumber(real, imaginary);
        }

        // --- Оператори ---
        public static ComplexNumber operator +(ComplexNumber c1, ComplexNumber c2) => new ComplexNumber(c1.Real + c2.Real, c1.Imaginary + c2.Imaginary);
        public static ComplexNumber operator -(ComplexNumber c1, ComplexNumber c2) => new ComplexNumber(c1.Real - c2.Real, c1.Imaginary - c2.Imaginary);

        public static ComplexNumber operator *(ComplexNumber c1, ComplexNumber c2) => new ComplexNumber(
            c1.Real * c2.Real - c1.Imaginary * c2.Imaginary,
            c1.Real * c2.Imaginary + c1.Imaginary * c2.Real);

        public static ComplexNumber operator /(ComplexNumber c1, ComplexNumber c2)
        {
            double denominator = c2.Real * c2.Real + c2.Imaginary * c2.Imaginary;
            if (denominator == 0) throw new DivideByZeroException("Ділення на нуль.");

            return new ComplexNumber(
                (c1.Real * c2.Real + c1.Imaginary * c2.Imaginary) / denominator,
                (c1.Imaginary * c2.Real - c1.Real * c2.Imaginary) / denominator);
        }

        // --- Спеціальні методи ---
        public static ComplexNumber Sqrt(ComplexNumber c)
        {
            c.ToTrigForm();
            double r = c._r.Value;
            double theta = c._theta.Value;

            double rSqrt = Math.Sqrt(r);
            double thetaHalf = theta / 2;

            return new ComplexNumber(rSqrt * Math.Cos(thetaHalf), rSqrt * Math.Sin(thetaHalf));
        }

        public static ComplexNumber Pow(ComplexNumber c, int n)
        {
            c.ToTrigForm();
            double r = c._r.Value;
            double theta = c._theta.Value;

            double rN = Math.Pow(r, n);
            double thetaN = theta * n;

            return new ComplexNumber(rN * Math.Cos(thetaN), rN * Math.Sin(thetaN));
        }

        public override string ToString()
        {
            if (Imaginary == 0) return Real.ToString("F4");
            if (Real == 0) return $"{Imaginary:F4}i";

            string sign = (Imaginary >= 0) ? "+" : "-";
            return $"{Real:F4} {sign} {Math.Abs(Imaginary):F4}i";
        }
    }
}