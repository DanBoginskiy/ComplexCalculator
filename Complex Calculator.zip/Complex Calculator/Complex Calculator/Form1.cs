using System.Net.Mail;
using System.Security.Cryptography.Xml;

namespace Complex_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox1.ReadOnly = true;
            textBox2.ReadOnly = true;
            textBox3.ReadOnly = true;
            textBox4.ReadOnly = true;
            textBox5.ReadOnly = true;
            label4.Hide();
            textBox3.Hide();
            radioButton12.Hide();
        }

        bool trigonometric = false;
        bool algebraic = true;
        bool box1_clicked = false;
        bool box2_clicked = false;
        bool box3_clicked = false;
        bool box4_clicked = false;
        bool box5_cliked = false;
        string box1_text = "";
        string box2_text = "";
        string box3_text = "";
        string box4_text = "";
        string box5_text = "";
        string op = "";


        private void Alg(object sender, EventArgs e)
        {
            algebraic = true;
            trigonometric = false;
            label1.Text = "a";
            label2.Text = "b";
            label6.Text = "a1";
            label5.Text = "b1";
        }

        private void Trig(object sender, EventArgs e)
        {
            trigonometric = true;
            algebraic = false;
            label1.Text = "phi";
            label2.Text = "r";
            label6.Text = "phi1";
            label5.Text = "r1";
        }
        private void Field1_CheckedChanged(object sender, EventArgs e)
        {
            box1_clicked = true;
            box2_clicked = false;
            box3_clicked = false;
            box4_clicked = false;
            box5_cliked = false;


            textBox1.BackColor = System.Drawing.SystemColors.Info;
            textBox2.BackColor = System.Drawing.SystemColors.Window;
            textBox3.BackColor = System.Drawing.SystemColors.Window;
            textBox4.BackColor = System.Drawing.SystemColors.Window;
            textBox5.BackColor = System.Drawing.SystemColors.Window;
        }
        private void Field2_CheckedChanged(object sender, EventArgs e)
        {

            box1_clicked = false;
            box2_clicked = true;
            box3_clicked = false;
            box4_clicked = false;
            box5_cliked = false;

            textBox1.BackColor = System.Drawing.SystemColors.Window;
            textBox2.BackColor = System.Drawing.SystemColors.Info;
            textBox3.BackColor = System.Drawing.SystemColors.Window;
            textBox4.BackColor = System.Drawing.SystemColors.Window;
            textBox5.BackColor = System.Drawing.SystemColors.Window;

        }
        private void Field3_CheckedChanged(object sender, EventArgs e)
        {
            box3_clicked = true;
            box1_clicked = false;
            box2_clicked = false;
            box4_clicked = false;
            box5_cliked = false;

            textBox3.BackColor = System.Drawing.SystemColors.Info;
            textBox1.BackColor = System.Drawing.SystemColors.Window;
            textBox2.BackColor = System.Drawing.SystemColors.Window;
            textBox4.BackColor = System.Drawing.SystemColors.Window;
            textBox5.BackColor = System.Drawing.SystemColors.Window;
        }
        private void Field4_CheckedChanged(object sender, EventArgs e)
        {
            box4_clicked = false;
            box1_clicked = false;
            box2_clicked = false;
            box3_clicked = false;
            box5_cliked = true;

            textBox4.BackColor = System.Drawing.SystemColors.Info;
            textBox1.BackColor = System.Drawing.SystemColors.Window;
            textBox2.BackColor = System.Drawing.SystemColors.Window;
            textBox3.BackColor = System.Drawing.SystemColors.Window;
            textBox5.BackColor = System.Drawing.SystemColors.Window;
        }
        private void Field5_CheckedChanged(object sender, EventArgs e)
        {
            box4_clicked = true;
            box1_clicked = false;
            box2_clicked = false;
            box3_clicked = false;
            box5_cliked = false;

            textBox5.BackColor = System.Drawing.SystemColors.Info;
            textBox1.BackColor = System.Drawing.SystemColors.Window;
            textBox2.BackColor = System.Drawing.SystemColors.Window;
            textBox3.BackColor = System.Drawing.SystemColors.Window;
            textBox4.BackColor = System.Drawing.SystemColors.Window;

        }
        private void NumberButton_Click(object sender, EventArgs e)
        {
            string value = ((Button)sender).Text;

            if (box1_clicked == true)
            {
                box1_text += value;
                textBox1.Text = box1_text;
            }
            else if (box2_clicked == true)
            {
                box2_text += value;
                textBox2.Text = box2_text;
            }
            else if (box3_clicked == true)
            {
                box3_text += value;
                textBox3.Text = box3_text;
            }
            else if (box4_clicked == true)
            {
                box4_text += value;
                textBox5.Text = box4_text;
            }
            else if (box5_cliked == true)
            {
                box5_text += value;
                textBox4.Text = box5_text;
            }
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            if (box1_clicked == true)
            {
                textBox1.Clear();
                box1_text = "";

            }
            else if (box2_clicked == true)
            {
                textBox2.Clear();
                box2_text = "";
            }
            else if (box3_clicked == true)
            {
                textBox3.Clear();
                box3_text = "";
            }
            else if (box4_clicked == true)
            {
                textBox5.Clear();
                box4_text = "";
            }
            else if (box5_cliked == true)
            {
                textBox4.Clear();
                box5_text = "";
            }
        }

        private void OperationalButton(object sender, EventArgs e)
        {
            op = "";
            op = ((RadioButton)sender).Text;

            box3_clicked = false;
            textBox3.BackColor = System.Drawing.SystemColors.Window;
            label4.Hide();
            textBox3.Hide();
            radioButton12.Hide();

        }
        private void SQRT_CheckedChanged(object sender, EventArgs e)
        {
            label4.Show();
            textBox3.Show();
            radioButton12.Show();
            op = "";
            op = "sqrt";
        }
        private void POW_CheckedChanged(object sender, EventArgs e)
        {
            label4.Show();
            textBox3.Show();
            radioButton12.Show();
            op = "^";
            op = "**";
        }
        private void Alter_CheckedChanged(object sender, EventArgs e)
        {
            op = "";
            op = "alt";
        }

        private void Eq_Click(object sender, EventArgs e)
        {
            if (algebraic == true)
            {
                double a = string.IsNullOrEmpty(box1_text) ? 0.0 : Convert.ToDouble(box1_text);
                double b = string.IsNullOrEmpty(box2_text) ? 0.0 : Convert.ToDouble(box2_text);
                double a1 = string.IsNullOrEmpty(box5_text) ? 0.0 : Convert.ToDouble(box5_text);
                double b1 = string.IsNullOrEmpty(box4_text) ? 0.0 : Convert.ToDouble(box4_text);
                double n = string.IsNullOrEmpty(box3_text) ? 1.0 : Convert.ToDouble(box3_text);

                AlgebraicComplex number = new AlgebraicComplex(a, b);
                AlgebraicComplex number1 = new AlgebraicComplex(a1, b1);
                switch (op)
                {
                    case "+":
                        {
                            AlgebraicComplex sum = number + number1;
                            label3.Text = sum.ToString();
                            break;
                        }
                    case "-":
                        {
                            AlgebraicComplex difference = number - number1;
                            label3.Text = difference.ToString();
                            break;
                        }
                    case "*":
                        {
                            AlgebraicComplex product = number * number1;
                            label3.Text = product.ToString();
                            break;
                        }
                    case "/":
                        {
                            AlgebraicComplex quotient = number / number1;
                            label3.Text = quotient.ToString();
                            break;
                        }
                    case "**":
                        {
                            AlgebraicComplex power = number.Power((int)n);
                            label3.Text = power.ToString();
                            break;
                        }
                    case "sqrt":
                        {
                            AlgebraicComplex root = number.Root((int)n, 0);
                            label3.Text = root.ToString();
                            break;
                        }
                    case "alt":
                        {
                            TrigonometricComplex altered = number.Totrig();
                            label3.Text = altered.ToString();
                            break;
                        }
                    default:
                        {
                            label3.Text = "�������";
                            break;
                        }
                }
            }
            else if (trigonometric == true)
            {
                double phi = string.IsNullOrEmpty(box1_text) ? 0.0 : Convert.ToDouble(box1_text);
                double r = string.IsNullOrEmpty(box2_text) ? 0.0 : Convert.ToDouble(box2_text);
                double phi1 = string.IsNullOrEmpty(box5_text) ? 0.0 : Convert.ToDouble(box5_text);
                double r1 = string.IsNullOrEmpty(box4_text) ? 0.0 : Convert.ToDouble(box4_text);
                double n = string.IsNullOrEmpty(box3_text) ? 1.0 : Convert.ToDouble(box3_text);

                TrigonometricComplex number = new TrigonometricComplex(phi, r);
                TrigonometricComplex number1 = new TrigonometricComplex(phi1, r1);
                switch (op)
                {
                    case "+":
                        {
                            TrigonometricComplex sum = number + number1;
                            label3.Text = sum.ToString();
                            break;
                        }
                    case "-":
                        {
                            TrigonometricComplex difference = number - number1;
                            label3.Text = difference.ToString();
                            break;
                        }
                    case "*":
                        {
                            TrigonometricComplex product = number * number1;
                            label3.Text = product.ToString();
                            break;
                        }
                    case "/":
                        {
                            TrigonometricComplex quotient = number / number1;
                            label3.Text = quotient.ToString();
                            break;
                        }
                    case "**":
                        {
                            TrigonometricComplex power = number.Power((int)n);
                            label3.Text = power.ToString();
                            break;
                        }
                    case "sqrt":
                        {
                            TrigonometricComplex root = number.Root((int)n);
                            label3.Text = root.ToString();
                            break;
                        }
                    case "alt":
                        {
                            AlgebraicComplex altered = number.Toalg();
                            label3.Text = altered.ToString();
                            break;
                        }
                    default:
                        {
                            label3.Text = "�������";
                            break;
                        }
                }
            }

        }
    }
}