﻿using System;
using System.Numerics;

namespace Complex_Calculator
{
    public class AlgebraicComplex
    {
        public double Real { get; private set; }
        public double Imaginary { get; private set; }

        private double r;
        private double theta;

        public AlgebraicComplex(double real, double imaginary)
        {
            this.Real = real;
            this.Imaginary = imaginary;
        }

        public static AlgebraicComplex operator +(AlgebraicComplex c1, AlgebraicComplex c2)
        {
            return new AlgebraicComplex(c1.Real + c2.Real, c1.Imaginary + c2.Imaginary);
        }

        public static AlgebraicComplex operator -(AlgebraicComplex c1, AlgebraicComplex c2)
        {
            return new AlgebraicComplex(c1.Real - c2.Real, c1.Imaginary - c2.Imaginary);
        }

        public static AlgebraicComplex operator *(AlgebraicComplex c1, AlgebraicComplex c2)
        {
            return new AlgebraicComplex(
                c1.Real * c2.Real - c1.Imaginary * c2.Imaginary,
                c1.Real * c2.Imaginary + c1.Imaginary * c2.Real);
        }

        public static AlgebraicComplex operator /(AlgebraicComplex c1, AlgebraicComplex c2)
        {
            double denominator = c2.Real * c2.Real + c2.Imaginary * c2.Imaginary;
            if (denominator == 0)
                throw new DivideByZeroException("Ділення на нуль (нульовий знаменник).");

            return new AlgebraicComplex(
                (c1.Real * c2.Real + c1.Imaginary * c2.Imaginary) / denominator,
                (c1.Imaginary * c2.Real - c1.Real * c2.Imaginary) / denominator);
        }

        private void ToTrigForm()
        {
            this.r = Math.Sqrt(Real * Real + Imaginary * Imaginary);
            this.theta = Math.Atan2(Imaginary, Real);
        }

        public AlgebraicComplex Power(int n)
        {
            ToTrigForm();

            double newR = Math.Pow(this.r, n);
            double newTheta = this.theta * n;

            double newReal = newR * Math.Cos(newTheta);
            double newImaginary = newR * Math.Sin(newTheta);

            return new AlgebraicComplex(newReal, newImaginary);
        }

        public AlgebraicComplex Root(int n, int k)
        {
            if (n <= 0)
                throw new ArgumentException("Степінь кореня має бути додатним цілим числом.");

            ToTrigForm();

            double newR = Math.Pow(this.r, 1.0 / n);

            double newTheta = (this.theta + 2 * Math.PI * k) / n;

            double newReal = newR * Math.Cos(newTheta);
            double newImaginary = newR * Math.Sin(newTheta);

            return new AlgebraicComplex(newReal, newImaginary);
        }

        public TrigonometricComplex Totrig() 
        { 
            double r = Math.Sqrt(Real * Real + Imaginary * Imaginary);
            double phi = Math.Atan2(Imaginary, Real);
            return  new TrigonometricComplex(r, phi);
        }

        public override string ToString()
        {
            if (Imaginary == 0)
            {
                return Real.ToString("F4");
            }
            else if (Real == 0)
            {
                return $"{Imaginary:F4}i";
            }
            else if (Imaginary < 0)
            {
                return $"{Real:F4} - {-Imaginary:F4}i";
            }
            else
            {
                return $"{Real:F4} + {Imaginary:F4}i";
            }
        }
    }
}